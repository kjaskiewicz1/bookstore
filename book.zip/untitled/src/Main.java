
import java.awt.print.Book;
import java.util.ArrayList;
import java.util.List;

@RequestMapping("BookDetail")
public class BookDetail{

    @PostMapping("add")
    public String addtosystem(@RequestParam String Book Object) {

    }

    @getMapping("retrieve")
    public  retrievebyISBN(@RequestParam Long bookId) {


    }
    @postMapping("Add author")
    public void addtoSystem(@RequestParam String Author Object) {

    }

    @getMapping("list")
    public List<Book> get(@RequestParam int AuthorID) {
      
        List<Book> books = new ArrayList<>();
        return books;
    }


}